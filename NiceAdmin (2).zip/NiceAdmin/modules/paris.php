
    <h1>PARIS</h1>
    <p>Paris is the capital city of France. It is one of the most populous cities in Europe, with a metropolitan area of over 11 million inhabitants.</p>
    <p>Situated on the River Seine, Paris has been a major center of art, fashion, and culture for centuries, often called "The City of Light."</p>